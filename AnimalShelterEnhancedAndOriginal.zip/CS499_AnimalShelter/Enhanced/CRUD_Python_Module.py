import os

from dotenv import load_dotenv
from pymongo import MongoClient

class AnimalShelter(object): 
    """CRUD and database operations for the MongoDB animal collection."""

    def __init__(self):
        """Initialize the MongoDB connection using environment configuration."""

        load_dotenv()

        mongo_uri = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
        database_name = os.getenv("MONGO_DB", "aac")
        collection_name = os.getenv("MONGO_COLLECTION", "animals")

        self.client = MongoClient(mongo_uri)
        self.database = self.client[database_name]
        self.collection = self.database[collection_name]

    # Validate animal data before create or update operations.
    @staticmethod
    def _validate_animal(data, require_all=True):
        """Validate animal data before it is written to the database."""

        if not isinstance(data, dict) or not data:
            raise ValueError("Animal data must be a non-empty dictionary.")

        required_fields = {
            "animal_id": str,
            "animal_type": str,
            "breed": str
        }

        if require_all:
            for field, expected_type in required_fields.items():
                if field not in data:
                    raise ValueError(f"Missing required field: {field}")

                if not isinstance(data[field], expected_type):
                    raise ValueError(
                        f"{field} must be of type {expected_type.__name__}."
                    )

                if not data[field].strip():
                    raise ValueError(f"{field} cannot be empty.")

        else:
            for field, expected_type in required_fields.items():
                if field in data:
                    if not isinstance(data[field], expected_type):
                        raise ValueError(
                            f"{field} must be of type {expected_type.__name__}."
                        )

                    if not data[field].strip():
                        raise ValueError(f"{field} cannot be empty.")


    # Create method to implement the C in CRUD.
    def create(self, data):
        """Create a new animal record after validating the data."""

        # Validate required fields and data types before inserting the record.
        self._validate_animal(data)

        try:
            # Insert the validated animal record into the MongoDB collection.
            self.collection.insert_one(data)
            return True
        except Exception as e:
            # Return False if MongoDB cannot complete the insert.
            print("Create Error:", e)
            return False

    # Read method to implement the R in CRUD.
    def read(self, query):
        """Read animal records that match the supplied query."""

        # MongoDB queries must be provided as dictionaries.
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")

        try:
            # Find matching records and exclude MongoDB's internal _id field.
            data = self.collection.find(query, {"_id": False})
            return list(data)
        except Exception as e:
            # Return an empty list if the database query fails.
            print("Read Error:", e)
            return []

    # Aggregate breed data for dashboard visualizations.
    def get_top_breeds(self, query=None, limit=10):
        """Return the most common breeds using a MongoDB aggregation pipeline."""

        # Use an empty query when no rescue filter is selected.
        if query is None:
            query = {}

        if not isinstance(query, dict):
            raise ValueError("Aggregation query must be a dictionary.")

        if not isinstance(limit, int) or limit <= 0:
            raise ValueError("Limit must be a positive integer.")

        # Perform filtering, grouping, sorting, and limiting inside MongoDB.
        pipeline = [
            {
                "$match": query
            },
            {
                "$match": {
                    "breed": {
                        "$type": "string",
                        "$ne": ""
                    }
                }
            },
            {
                "$group": {
                    "_id": "$breed",
                    "count": {"$sum": 1}
                }
            },
            {
                "$sort": {
                    "count": -1,
                    "_id": 1
                }
            },
            {
                "$limit": limit
            },
            {
                "$project": {
                    "_id": 0,
                    "breed": "$_id",
                    "count": 1
                }
            }
        ]

        try:
            return list(self.collection.aggregate(pipeline))
        except Exception as e:
            print("Aggregation Error:", e)
            return []

    # Create an index to improve the performance of rescue-related queries.
    def create_rescue_index(self):
        """Create a compound index for fields used by dashboard rescue filters."""

        try:
            # Create a compound index based on fields used by the rescue queries.
            index_name = self.collection.create_index([
                ("animal_type", 1),
                ("sex_upon_outcome", 1),
                ("breed", 1),
                ("age_upon_outcome_in_weeks", 1)
            ])

            return index_name

        except Exception as e:
            print("Index Creation Error:", e)
            return None

    # Update method to implement the U in CRUD.
    def update(self, query, update_data):
        """Update animal records after validating the new data."""

        # Require a specific query to prevent accidentally updating every record.
        if not isinstance(query, dict) or not query:
            raise ValueError("Update query must be a non-empty dictionary.")

        # Validate the fields being changed before sending them to MongoDB.
        self._validate_animal(update_data, require_all=False)

        try:
            # Update all animal records that match the supplied query.
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count
        except Exception as e:
            # Return zero if MongoDB cannot complete the update.
            print("Update Error:", e)
            return 0

    # Delete method to implement the D in CRUD.
    def delete(self, query):
        """Delete animal records that match the supplied query."""

        # Require a specific query to prevent accidentally deleting every record.
        if not isinstance(query, dict) or not query:
            raise ValueError("Delete query must be a non-empty dictionary.")

        try:
            # Delete all animal records that match the supplied query.
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            # Return zero if MongoDB cannot complete the delete operation.
            print("Delete Error:", e)
            return 0

    # Close the MongoDB connection when database operations are complete.
    def close(self):
        """Close the MongoDB client connection."""
        self.client.close()