from CRUD_Python_Module import AnimalShelter

# Connect to the Animal Shelter database.
shelter = AnimalShelter()

# Use the same Water Rescue criteria as the dashboard.
water_query = {
    "animal_type": "Dog",
    "breed": {
        "$regex": "Labrador Retriever|Chesapeake Bay Retriever|Newfoundland",
        "$options": "i"
    },
    "sex_upon_outcome": "Intact Female",
    "age_upon_outcome_in_weeks": {
        "$gte": 26,
        "$lte": 156
    }
}

# Let MongoDB calculate the most common breeds within the filtered records.
top_water_breeds = shelter.get_top_breeds(
    query=water_query,
    limit=10
)

print("--- TOP WATER RESCUE BREEDS ---")

for position, breed in enumerate(top_water_breeds, start=1):
    print(
        f"{position}. {breed['breed']}: "
        f"{breed['count']} animals"
    )

# Confirm that the aggregation is based on the same records
# returned by the original dashboard query.
matching_records = shelter.read(water_query)

print("\nWater Rescue records:", len(matching_records))
print(
    "Records represented in aggregation:",
    sum(breed["count"] for breed in top_water_breeds)
)

shelter.client.close()