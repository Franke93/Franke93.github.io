from CRUD_Python_Module import AnimalShelter

# Connect to the Animal Shelter MongoDB collection.
shelter = AnimalShelter()
collection = shelter.collection

# Remove the rescue index if it already exists so the test begins
# with the same unindexed baseline each time.
index_name = (
    "animal_type_1_sex_upon_outcome_1_"
    "breed_1_age_upon_outcome_in_weeks_1"
)

if index_name in collection.index_information():
    collection.drop_index(index_name)
    print("Existing rescue index removed for baseline test.\n")

# Use the original Water Rescue dashboard query for the performance test.
water_query = {
    "animal_type": "Dog",
    "breed": {
        "$regex": "Labrador Retriever|Chesapeake Bay Retriever|Newfoundland",
        "$options": "i"
    },
    "sex_upon_outcome": "Intact Female",
    "age_upon_outcome_in_weeks": {
        "$gte": 26,
        "$lte": 156
    }
}

# Ask MongoDB to explain how it executes the query.
explain_result = shelter.database.command(
    "explain",
    {
        "find": collection.name,
        "filter": water_query
    },
    verbosity="executionStats"
)

execution_stats = explain_result["executionStats"]

print("--- BEFORE INDEX ---")
print("Records returned:", execution_stats["nReturned"])
print("Documents examined:", execution_stats["totalDocsExamined"])
print("Index keys examined:", execution_stats["totalKeysExamined"])
print("Execution time (ms):", execution_stats["executionTimeMillis"])

print("\nCreating rescue query index...")

index_name = shelter.create_rescue_index()

print("Index created:", index_name)

# Run the exact same query again after creating the index.
explain_result_after = shelter.database.command(
    "explain",
    {
        "find": collection.name,
        "filter": water_query
    },
    verbosity="executionStats"
)

execution_stats_after = explain_result_after["executionStats"]

print("\n--- AFTER INDEX ---")
print("Records returned:", execution_stats_after["nReturned"])
print("Documents examined:", execution_stats_after["totalDocsExamined"])
print("Index keys examined:", execution_stats_after["totalKeysExamined"])
print("Execution time (ms):", execution_stats_after["executionTimeMillis"])

shelter.client.close()