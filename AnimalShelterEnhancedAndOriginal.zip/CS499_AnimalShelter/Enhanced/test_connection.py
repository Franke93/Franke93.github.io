from CRUD_Python_Module import AnimalShelter

shelter = AnimalShelter()

# Test the database connection and read operation.
records = shelter.read({})
print("Connected successfully")
print("Animal records:", len(records))

print("\n--- Validation Tests ---")

# Test 1: Missing required breed field.
try:
    invalid_animal = {
        "animal_id": "TEST001",
        "animal_type": "Dog"
    }

    shelter.create(invalid_animal)

except ValueError as e:
    print("Test 1 passed:", e)


# Test 2: Incorrect data type for animal_id.
try:
    invalid_animal = {
        "animal_id": 12345,
        "animal_type": "Dog",
        "breed": "Labrador Retriever"
    }

    shelter.create(invalid_animal)

except ValueError as e:
    print("Test 2 passed:", e)


# Test 3: Prevent an empty update query.
try:
    shelter.update({}, {"breed": "Labrador Retriever"})

except ValueError as e:
    print("Test 3 passed:", e)


# Test 4: Prevent an empty delete query.
try:
    shelter.delete({})

except ValueError as e:
    print("Test 4 passed:", e)


# Confirm that no records were added or deleted during testing.
records_after_test = shelter.read({})
print("\nAnimal records after testing:", len(records_after_test))

shelter.client.close()