# Animal Shelter Dashboard
# Enhanced CS 499 database artifact

from dash import Dash, dcc, html, dash_table
from dash.dependencies import Input, Output
import dash_leaflet as dl
import pandas as pd
import plotly.express as px

from CRUD_Python_Module import AnimalShelter


# Connect to the Animal Shelter MongoDB database.
db = AnimalShelter()


# Load the initial animal data for the dashboard.
df = pd.DataFrame.from_records(db.read({}))

# Remove MongoDB's internal ID field if it is present.
if "_id" in df.columns:
    df.drop(columns=["_id"], inplace=True)


# Create the Dash application.
app = Dash(__name__)


# Build the MongoDB query for the selected rescue type.
def build_rescue_query(filter_type):
    """Return the MongoDB query associated with a dashboard rescue filter."""

    if filter_type == "water":
        return {
            "animal_type": "Dog",
            "breed": {
                "$regex": "Labrador Retriever|Chesapeake Bay Retriever|Newfoundland",
                "$options": "i"
            },
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": {
                "$gte": 26,
                "$lte": 156
            }
        }

    if filter_type == "mountain":
        return {
            "animal_type": "Dog",
            "breed": {
                "$regex": (
                    "German Shepherd|Alaskan Malamute|Old English Sheepdog|"
                    "Siberian Husky|Rottweiler"
                ),
                "$options": "i"
            },
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {
                "$gte": 26,
                "$lte": 156
            }
        }

    if filter_type == "disaster":
        return {
            "animal_type": "Dog",
            "breed": {
                "$regex": (
                    "Doberman Pinscher|German Shepherd|Golden Retriever|"
                    "Bloodhound|Rottweiler"
                ),
                "$options": "i"
            },
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {
                "$gte": 20,
                "$lte": 300
            }
        }

    # Reset or an unknown filter returns all animal records.
    return {}

# Define the dashboard layout.
app.layout = html.Div([

    # Dashboard title.
    html.H1(
        "Grazioso Salvare Animal Shelter Dashboard",
        style={"textAlign": "center"}
    ),

    html.Hr(),

    # Rescue-type filter controls.
    html.Div([
        html.Label("Select Rescue Type:"),

        dcc.RadioItems(
            id="filter-type",
            options=[
                {"label": "Water Rescue", "value": "water"},
                {"label": "Mountain or Wilderness Rescue", "value": "mountain"},
                {"label": "Disaster or Individual Tracking", "value": "disaster"},
                {"label": "Reset", "value": "reset"}
            ],
            value="reset",
            inline=True
        )
    ]),

    html.Hr(),

    # Interactive animal data table.
    dash_table.DataTable(
        id="datatable-id",
        columns=[
            {"name": column, "id": column}
            for column in df.columns
        ],
        data=df.to_dict("records"),
        page_size=10,
        sort_action="native",
        filter_action="native",
        row_selectable="single",
        selected_rows=[0],
        style_table={
            "overflowX": "auto"
        }
    ),

    html.Br(),

    # Breed distribution chart.
    html.Div(
        id="graph-id",
        style={
            "width": "100%"
        }
    ),

    html.Hr(),

    # Location map.
    html.Div(
        id="map-id",
        style={
            "width": "100%"
        }
    )
])

# Update the animal table when the rescue filter changes.
@app.callback(
    Output("datatable-id", "data"),
    Input("filter-type", "value")
)
def update_dashboard(filter_type):
    """Display animal records that match the selected rescue criteria."""

    # Build the appropriate MongoDB query.
    query = build_rescue_query(filter_type)

    # Retrieve only the records that match the selected filter.
    records = db.read(query)

    return records

# Update the breed chart when the rescue filter changes.
@app.callback(
    Output("graph-id", "children"),
    Input("filter-type", "value")
)
def update_graphs(filter_type):
    """Display the top breeds using MongoDB aggregation."""

    # Use the same rescue query as the animal data table.
    query = build_rescue_query(filter_type)

    # MongoDB performs the filtering, grouping, sorting, and limiting.
    breed_data = db.get_top_breeds(query=query, limit=10)

    # Display a message if the selected filter has no matching breed data.
    if not breed_data:
        return [
            html.H4("No breed data available for this filter.")
        ]

    # Create a pie chart from the aggregated MongoDB results.
    fig = px.pie(
        values=[item["count"] for item in breed_data],
        names=[item["breed"] for item in breed_data],
        title="Top 10 Breed Distribution"
    )

    # Adjust the chart layout for easier viewing.
    fig.update_layout(
        height=600,
        showlegend=True
    )

    fig.update_traces(
        textposition="inside",
        textinfo="percent+label"
    )

    return [
        dcc.Graph(
            figure=fig,
            style={
                "height": "600px",
                "width": "100%"
            }
        )
    ]

# Update the map when a row is selected in the animal data table.
@app.callback(
    Output("map-id", "children"),
    [
        Input("datatable-id", "derived_virtual_data"),
        Input("datatable-id", "derived_virtual_selected_rows")
    ]
)
def update_map(view_data, selected_rows):
    """Display the selected animal's location on the map."""

    # Do not create a map if the table contains no data.
    if not view_data:
        return [
            html.H4("No location data available.")
        ]

    # Convert the currently displayed table records to a DataFrame.
    dff = pd.DataFrame.from_dict(view_data)

    # Use the first row when no row has been selected.
    if not selected_rows:
        row = 0
    else:
        row = selected_rows[0]

    # Make sure the selected row still exists after filtering.
    if row >= len(dff):
        row = 0

    # Get location information using field names instead of column positions.
    latitude = dff.iloc[row]["location_lat"]
    longitude = dff.iloc[row]["location_long"]
    breed = dff.iloc[row]["breed"]
    animal_id = dff.iloc[row]["animal_id"]

    # Display the selected animal's location.
    return [
        dl.Map(
            style={
                "width": "100%",
                "height": "500px"
            },
            center=[latitude, longitude],
            zoom=10,
            children=[
                dl.TileLayer(),
                dl.Marker(
                    position=[latitude, longitude],
                    children=[
                        dl.Tooltip(breed),
                        dl.Popup([
                            html.H4("Animal Information"),
                            html.P(f"Animal ID: {animal_id}"),
                            html.P(f"Breed: {breed}")
                        ])
                    ]
                )
            ]
        )
    ]

# Run the dashboard as a standalone Dash application.
if __name__ == "__main__":
    app.run(debug=False)
