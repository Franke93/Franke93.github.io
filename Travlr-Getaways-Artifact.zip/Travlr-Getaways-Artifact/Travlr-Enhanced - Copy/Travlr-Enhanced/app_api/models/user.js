const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Define the user schema for authentication and authorization
const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: true
  },

  name: {
    type: String,
    required: true
  },

  // Enhancement:
  // Added role-based access control (RBAC) to distinguish
  // between administrators and users with view-only permissions.
  // New users receive the least-privileged viewer role by default.
  role: {
    type: String,
    enum: ['admin', 'viewer'],
    default: 'viewer'
  },

  // Passwords are not stored directly.
  // The salt and hash are used to securely verify passwords.
  hash: String,
  salt: String
});

// Creates a salt and hashed version of the user's password
userSchema.methods.setPassword = function(password) {
  this.salt = crypto.randomBytes(16).toString('hex');

  this.hash = crypto.pbkdf2Sync(
    password,
    this.salt,
    1000,
    64,
    'sha512'
  ).toString('hex');
};

// Checks a submitted password against the stored password hash
userSchema.methods.validPassword = function(password) {
  const hash = crypto.pbkdf2Sync(
    password,
    this.salt,
    1000,
    64,
    'sha512'
  ).toString('hex');

  return this.hash === hash;
};

// Generates a JWT after successful authentication
userSchema.methods.generateJWT = function() {
  const expiry = new Date();

  // Token expires after seven days
  expiry.setDate(expiry.getDate() + 7);

  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name,

      // Enhancement:
      // Include the user's role in the JWT so protected API routes
      // can determine whether the user is authorized for an operation.
      role: this.role,

      exp: parseInt(expiry.getTime() / 1000, 10)
    },

    process.env.JWT_SECRET
  );
};

// Register the schema with Mongoose
mongoose.model('users', userSchema);