const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema({

  code: {
    type: String,
    required: true,
    index: true
  },

  name: {
    type: String,
    required: true,
    index: true
  },

  length: {
    type: String,
    required: true
  },

  start: {
    type: Date,
    required: true
  },

  resort: {
    type: String,
    required: true
  },

  // Enhancement:
  // Changed the trip price from a String to a Number so the
  // database stores price data using the appropriate data type.
  // A minimum value prevents negative trip prices.
  perPerson: {
    type: Number,
    required: true,
    min: 0
  },

  image: {
    type: String,
    required: true
  },

  description: {
    type: String,
    required: true
  }

});

const Trip = mongoose.model('trips', tripSchema);

module.exports = Trip;