const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authenticationController = require('../controllers/authentication');

// Method to authenticate the JWT
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];

  // Enhancement:
  // Return a controlled authentication response when an
  // authorization header is not included with the request.
  if (authHeader == null) {
    return res.status(401).json({
      message: 'Authorization header required'
    });
  }

  const headers = authHeader.split(' ');

  // Enhancement:
  // Validate the expected "Bearer <token>" authorization format.
  if (headers.length !== 2 || headers[0] !== 'Bearer') {
    return res.status(401).json({
      message: 'Invalid authorization header'
    });
  }

  const token = headers[1];

  if (!token) {
    return res.status(401).json({
      message: 'Bearer token required'
    });
  }

  // Verify that the token was created using the application's secret
  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if (err) {
      return res.status(401).json({
        message: 'Invalid or expired token'
      });
    }

    // Store the verified JWT information on the request.
    // This includes the user's role added during the CS 499 enhancement.
    req.auth = verified;

    next();
  });
}

// Enhancement:
// Role-based authorization middleware.
// Authentication confirms who the user is, while this middleware
// determines whether the authenticated user has permission to
// perform the requested operation.
function authorizeRole(...allowedRoles) {
  return (req, res, next) => {

    // The request must first pass authenticateJWT.
    if (!req.auth) {
      return res.status(401).json({
        message: 'Authentication required'
      });
    }

    // Check the role stored in the verified JWT against the roles
    // that are permitted to access this route.
    if (!allowedRoles.includes(req.auth.role)) {
      return res.status(403).json({
        message: 'You do not have permission to perform this action'
      });
    }

    next();
  };
}

// Registration endpoint
router
  .route('/register')
  .post(authenticationController.register);

// Login endpoint
router
  .route('/login')
  .post(authenticationController.login);

// Trip collection routes
router
  .route('/trips')
  .get(tripsController.tripsList)

  // Enhancement:
  // Adding trips now requires both authentication and
  // administrator authorization.
  .post(
    authenticateJWT,
    authorizeRole('admin'),
    tripsController.tripsAddTrip
  );

// Individual trip routes
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)

  // Enhancement:
  // Updating trips is restricted to authenticated administrators.
  .put(
    authenticateJWT,
    authorizeRole('admin'),
    tripsController.tripsUpdateTrip
  )

  // Enhancement:
  // Deleting trips is restricted to authenticated administrators.
  .delete(
    authenticateJWT,
    authorizeRole('admin'),
    tripsController.tripsDeleteTrip
  );

module.exports = router;