const mongoose = require('mongoose');
const passport = require('passport');

const User = mongoose.model('users');

// Register a new user
const register = async (req, res) => {

  // Make sure all required registration fields were provided
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res.status(400).json({
      message: 'All fields required'
    });
  }

  const user = new User();

  user.name = req.body.name;
  user.email = req.body.email;

  // Enhancement:
  // New accounts are assigned the least-privileged viewer role.
  // The server assigns the role instead of accepting req.body.role,
  // preventing users from registering themselves as administrators.
  user.role = 'viewer';

  // Hash and store the user's password
  user.setPassword(req.body.password);

  try {
    await user.save();

    // Generate a JWT containing the user's identity and role
    const token = user.generateJWT();

    return res.status(200).json({
      token
    });

  } catch (err) {

    // Enhancement:
    // Provide a controlled registration error response rather than
    // returning the raw database error directly to the client.
    return res.status(400).json({
      message: 'Unable to register user',
      error: err.message
    });
  }
};

// Authenticate an existing user
const login = (req, res) => {

  // Email and password are required to log in
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({
      message: 'All fields required'
    });
  }

  passport.authenticate('local', (err, user, info) => {

    // Enhancement:
    // Authentication system failures are treated as server errors
    // instead of returning a 404 Not Found response.
    if (err) {
      return res.status(500).json({
        message: 'Authentication error'
      });
    }

    // If authentication succeeds, create a JWT.
    // The token now includes the user's authorization role.
    if (user) {
      const token = user.generateJWT();

      return res.status(200).json({
        token
      });
    }

    // Credentials were not valid
    return res.status(401).json(
      info || {
        message: 'Invalid email or password'
      }
    );

  })(req, res);
};

module.exports = {
  register,
  login
};