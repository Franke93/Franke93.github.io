const mongoose = require('mongoose');
require('../models/travlr');

const Trip = mongoose.model('trips');

// Enhancement:
// Validate trip data on the server before allowing database changes.
// Server-side validation is required even if Angular also validates
// the form because API requests can be sent without using the UI.
const validateTrip = (tripData) => {
  const errors = [];

  if (!tripData.code || !tripData.code.trim()) {
    errors.push('Trip code is required');
  }

  if (!tripData.name || !tripData.name.trim()) {
    errors.push('Trip name is required');
  }

  if (!tripData.length || !tripData.length.trim()) {
    errors.push('Trip length is required');
  }

  if (!tripData.start) {
    errors.push('Start date is required');
  }

  if (!tripData.resort || !tripData.resort.trim()) {
    errors.push('Resort is required');
  }

  if (
    tripData.perPerson === undefined ||
    tripData.perPerson === null ||
    tripData.perPerson === ''
  ) {
    errors.push('Price per person is required');
  } else if (
    Number.isNaN(Number(tripData.perPerson)) ||
    Number(tripData.perPerson) < 0
  ) {
    errors.push('Price per person must be a valid positive number');
  }

  if (!tripData.image || !tripData.image.trim()) {
    errors.push('Trip image is required');
  }

  if (!tripData.description || !tripData.description.trim()) {
    errors.push('Trip description is required');
  }

  return errors;
};


// GET /api/trips
// Return a list of all trips
const tripsList = async (req, res) => {
  try {
    const trips = await Trip
      .find({})
      .exec();

    // Enhancement:
    // Mongoose find() returns an empty array when no records exist,
    // so explicitly check the array length.
    if (!trips || trips.length === 0) {
      return res
        .status(404)
        .json({
          message: 'No trips found'
        });
    }

    return res
      .status(200)
      .json(trips);

  } catch (err) {

    // Enhancement:
    // Return a controlled error message rather than exposing
    // database error details directly to the client.
    return res
      .status(500)
      .json({
        message: 'Unable to retrieve trips'
      });
  }
};


// GET /api/trips/:tripCode
// Return a single trip using its code
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip
      .findOne({ code: req.params.tripCode })
      .exec();

    // Enhancement:
    // findOne() is more appropriate here because trip codes
    // identify individual trips.
    if (!trip) {
      return res
        .status(404)
        .json({
          message: 'Trip not found'
        });
    }

    return res
      .status(200)
      .json(trip);

  } catch (err) {
    return res
      .status(500)
      .json({
        message: 'Unable to retrieve trip'
      });
  }
};


// POST /api/trips
// Add a new trip
const tripsAddTrip = async (req, res) => {

  // Enhancement:
  // Validate incoming trip information before attempting
  // to create a database record.
  const validationErrors = validateTrip(req.body);

  if (validationErrors.length > 0) {
    return res
      .status(400)
      .json({
        message: 'Invalid trip data',
        errors: validationErrors
      });
  }

  try {

    // Enhancement:
    // Prevent duplicate trip codes from being created.
    const existingTrip = await Trip
      .findOne({ code: req.body.code })
      .exec();

    if (existingTrip) {
      return res
        .status(409)
        .json({
          message: 'A trip with this code already exists'
        });
    }

    const newTrip = new Trip({
      code: req.body.code.trim(),
      name: req.body.name.trim(),
      length: req.body.length.trim(),
      start: req.body.start,
      resort: req.body.resort.trim(),
      perPerson: Number(req.body.perPerson),
      image: req.body.image.trim(),
      description: req.body.description.trim()
    });

    const trip = await newTrip.save();

    return res
      .status(201)
      .json(trip);

  } catch (err) {
    return res
      .status(500)
      .json({
        message: 'Unable to create trip'
      });
  }
};


// PUT /api/trips/:tripCode
// Update an existing trip
const tripsUpdateTrip = async (req, res) => {

  // Enhancement:
  // Validate updated trip information before modifying
  // the existing database record.
  const validationErrors = validateTrip(req.body);

  if (validationErrors.length > 0) {
    return res
      .status(400)
      .json({
        message: 'Invalid trip data',
        errors: validationErrors
      });
  }

  try {
    const trip = await Trip
      .findOneAndUpdate(
        { code: req.params.tripCode },
        {
          code: req.body.code.trim(),
          name: req.body.name.trim(),
          length: req.body.length.trim(),
          start: req.body.start,
          resort: req.body.resort.trim(),
          perPerson: Number(req.body.perPerson),
          image: req.body.image.trim(),
          description: req.body.description.trim()
        },
        {
          new: true,
          runValidators: true
        }
      )
      .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message: 'Trip not found'
        });
    }

    // Enhancement:
    // Return 200 OK for a successful update instead of
    // 201 Created, which is intended for newly created resources.
    return res
      .status(200)
      .json(trip);

  } catch (err) {
    return res
      .status(500)
      .json({
        message: 'Unable to update trip'
      });
  }
};


// DELETE /api/trips/:tripCode
// Delete an existing trip
const tripsDeleteTrip = async (req, res) => {
  try {
    const trip = await Trip
      .findOneAndDelete({
        code: req.params.tripCode
      })
      .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message: 'Trip not found'
        });
    }

    return res
      .status(204)
      .send();

  } catch (err) {

    // Enhancement:
    // Return a controlled server error without exposing
    // internal database information.
    return res
      .status(500)
      .json({
        message: 'Unable to delete trip'
      });
  }
};


module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};