export class User {

  email: string;

  name: string;

  // Enhancement:
  // Added the user's authorization role so the Angular
  // application can distinguish between administrators
  // and users with view-only permissions.
  role: string;

  constructor() {

    this.email = '';

    this.name = '';

    // Enhancement:
    // Default to the viewer role to follow the principle
    // of least privilege.
    this.role = 'viewer';

  }

}