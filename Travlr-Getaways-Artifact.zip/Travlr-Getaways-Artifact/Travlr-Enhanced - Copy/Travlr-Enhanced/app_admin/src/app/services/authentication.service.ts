import { Inject, Injectable } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { TripDataService } from './trip-data.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  authResp: AuthResponse = new AuthResponse();

  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private tripDataService: TripDataService
  ) { }

  // Get JWT from local storage
  public getToken(): string {
    const token = this.storage.getItem('travlr-token');

    if (!token) {
      return '';
    }

    return token;
  }

  // Save JWT to local storage
  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  // Remove JWT when logging out
  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  // Check whether the user is logged in and the token is valid
  public isLoggedIn(): boolean {
    const token: string = this.getToken();

    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));

        return payload.exp > (Date.now() / 1000);
      } catch (error) {
        return false;
      }
    }

    return false;
  }

  // Enhancement:
  // Decode the JWT and return the authenticated user's role.
  // The role is used by Angular to determine which administrative
  // controls should be displayed in the interface.
  public getUserRole(): string {
    const token: string = this.getToken();

    if (!token) {
      return '';
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));

      return payload.role || '';
    } catch (error) {
      return '';
    }
  }

  // Enhancement:
  // Determine whether the currently authenticated user has
  // administrator permissions.
  public isAdmin(): boolean {
    return this.isLoggedIn() && this.getUserRole() === 'admin';
  }

  // Enhancement:
  // Determine whether the authenticated user has the viewer role.
  public isViewer(): boolean {
    return this.isLoggedIn() && this.getUserRole() === 'viewer';
  }

  // Get information about the currently logged-in user
  public getCurrentUser(): User {
    const token: string = this.getToken();

    if (!token) {
      return {} as User;
    }

    try {
      // Enhancement:
      // Include the user's authorization role when retrieving
      // information from the JWT.
      const { email, name, role } =
        JSON.parse(atob(token.split('.')[1]));

      return {
        email,
        name,
        role
      } as User;

    } catch (error) {
      return {} as User;
    }
  }

  // Login and save returned JWT
  public login(user: User, passwd: string): void {
    this.tripDataService.login(user, passwd)
      .subscribe({
        next: (value: any) => {
          if (value) {
            console.log(value);
            this.authResp = value;
            this.saveToken(this.authResp.token);
          }
        },
        error: (error: any) => {
          console.log('Error: ' + error);
        }
      });
  }

  // Register a new user and save returned JWT
  public register(user: User, passwd: string): void {
    this.tripDataService.register(user, passwd)
      .subscribe({
        next: (value: any) => {
          if (value) {
            console.log(value);
            this.authResp = value;
            this.saveToken(this.authResp.token);
          }
        },
        error: (error: any) => {
          console.log('Error: ' + error);
        }
      });
  }
}