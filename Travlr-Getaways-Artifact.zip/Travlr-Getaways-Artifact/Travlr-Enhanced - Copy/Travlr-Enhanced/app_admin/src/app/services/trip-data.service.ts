import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private baseUrl = 'http://localhost:3000/api';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) { }

  getTrips(): Observable<Trip[]> {
    const url = `${this.baseUrl}/trips`;
    return this.http.get<Trip[]>(url);
  }

  getTrip(tripCode: string): Observable<Trip> {
    const url = `${this.baseUrl}/trips/${tripCode}`;
    return this.http.get<Trip>(url);
  }

  addTrip(trip: Trip): Observable<Trip> {
    const url = `${this.baseUrl}/trips`;

    return this.http.post<Trip>(url, trip, {
      headers: this.getAuthHeaders()
    });
  }

  updateTrip(trip: Trip): Observable<Trip> {
    const url = `${this.baseUrl}/trips/${trip.code}`;

    return this.http.put<Trip>(url, trip, {
      headers: this.getAuthHeaders()
    });
  }

  deleteTrip(tripCode: string): Observable<any> {
    const url = `${this.baseUrl}/trips/${tripCode}`;

    return this.http.delete(url, {
      headers: this.getAuthHeaders()
    });
  }

  // Call to our /login endpoint, returns JWT
  login(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('login', user, passwd);
  }

  // Call to our /register endpoint, creates user and returns JWT
  register(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('register', user, passwd);
  }

  // Helper method to process both login and register methods
  private handleAuthAPICall(
    endpoint: string,
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };

    return this.http.post<AuthResponse>(
      `${this.baseUrl}/${endpoint}`,
      formData
    );
  }

  // Create Authorization header for protected API calls
  private getAuthHeaders(): HttpHeaders {
    const token = this.storage.getItem('travlr-token');

    return new HttpHeaders({
      Authorization: `Bearer ${token || ''}`
    });
  }
}