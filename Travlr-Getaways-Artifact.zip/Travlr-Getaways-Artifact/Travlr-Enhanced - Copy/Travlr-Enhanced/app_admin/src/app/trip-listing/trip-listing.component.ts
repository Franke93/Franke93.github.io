import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { AuthenticationService } from '../services/authentication.service';
import { TripCardComponent } from '../trip-card/trip-card.component';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.component.html',
  styleUrl: './trip-listing.component.css'
})

export class TripListingComponent implements OnInit {

  trips: Trip[] = [];

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  // Check whether a user is currently authenticated
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  // Enhancement:
  // Check whether the authenticated user has administrator
  // permissions before displaying administrative controls.
  public isAdmin(): boolean {
    return this.authenticationService.isAdmin();
  }

  // Navigate to the Add Trip page
  public addTrip(): void {

    // Enhancement:
    // Prevent non-administrator users from navigating to the
    // Add Trip page through this component.
    if (!this.isAdmin()) {
      return;
    }

    this.router.navigate(['add-trip']);
  }

  ngOnInit(): void {

    this.tripDataService.getTrips().subscribe({

      next: (value: Trip[]) => {
        this.trips = value;
      },

      error: (error: any) => {
        console.log('Error: ' + error);
      }

    });

  }

}