import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { AuthenticationService } from './services/authentication.service';

// Enhancement:
// Route guard that prevents users without administrator
// permissions from accessing protected administrative pages.
export const adminGuard: CanActivateFn = () => {

  const authenticationService = inject(AuthenticationService);
  const router = inject(Router);

  // Allow access only when the authenticated user
  // has the administrator role.
  if (authenticationService.isAdmin()) {
    return true;
  }

  // Enhancement:
  // Redirect unauthorized users back to the trip listing
  // instead of allowing access to Add/Edit pages.
  return router.createUrlTree(['/']);
};