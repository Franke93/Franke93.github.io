import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { TripDataService } from '../services/trip-data.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.component.html',
  styleUrl: './trip-card.component.css'
})
export class TripCardComponent implements OnInit {

  @Input('trip') trip: any;

  constructor(
    private router: Router,
    private tripDataService: TripDataService,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit(): void {

  }

  // Check whether a user is currently authenticated
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  // Enhancement:
  // Determine whether the authenticated user has administrator
  // permissions before displaying or using modification controls.
  public isAdmin(): boolean {
    return this.authenticationService.isAdmin();
  }

  public editTrip(trip: any): void {

    // Enhancement:
    // Prevent non-administrator users from navigating to the
    // Edit Trip page through this component.
    if (!this.isAdmin()) {
      return;
    }

    localStorage.removeItem('tripCode');
    localStorage.setItem('tripCode', trip.code);

    this.router.navigate(['edit-trip']);
  }

  public deleteTrip(trip: any): void {

    // Enhancement:
    // Prevent non-administrator users from attempting a delete
    // operation through the Angular application.
    if (!this.isAdmin()) {
      return;
    }

    if (confirm(`Are you sure you want to delete ${trip.name}?`)) {

      this.tripDataService.deleteTrip(trip.code).subscribe({

        next: () => {
          window.location.reload();
        },

        error: (error: any) => {
          console.log('Error: ' + error);
        }

      });
    }
  }
}