package com.example.weighttracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class WeightGridActivity : ComponentActivity() {

    private lateinit var databaseHelper: WeightDatabaseHelper
    private val SMS_PERMISSION_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_grid)

        databaseHelper = WeightDatabaseHelper(this)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_CODE
            )
        }

        val weightList = findViewById<TextView>(R.id.textWeightList)
        val entryId = findViewById<EditText>(R.id.editTextEntryId)
        val dateInput = findViewById<EditText>(R.id.editTextDate)
        val weightInput = findViewById<EditText>(R.id.editTextWeight)
        val goalWeightInput = findViewById<EditText>(R.id.editTextGoalWeight)

        val addButton = findViewById<Button>(R.id.buttonAddWeight)
        val updateButton = findViewById<Button>(R.id.buttonUpdateWeight)
        val deleteButton = findViewById<Button>(R.id.buttonDeleteWeight)
        val smsSettingsButton = findViewById<Button>(R.id.buttonSmsSettings)

        weightList.text = databaseHelper.getAllWeights()

        addButton.setOnClickListener {
            val date = dateInput.text.toString()
            val weightText = weightInput.text.toString()

            if (date.isNotEmpty() && weightText.isNotEmpty()) {
                val currentWeight = weightText.toDouble()
                val success = databaseHelper.addWeight(date, currentWeight)

                if (success) {
                    Toast.makeText(this, "Weight added", Toast.LENGTH_SHORT).show()
                    weightList.text = databaseHelper.getAllWeights()

                    if (goalWeightInput.text.isNotEmpty()) {
                        val goalWeight = goalWeightInput.text.toString().toDouble()

                        if (currentWeight <= goalWeight) {
                            sendGoalSms()
                        }
                    }
                } else {
                    Toast.makeText(this, "Failed to add weight", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show()
            }
        }

        updateButton.setOnClickListener {
            val idText = entryId.text.toString()
            val date = dateInput.text.toString()
            val weightText = weightInput.text.toString()

            if (idText.isNotEmpty() && date.isNotEmpty() && weightText.isNotEmpty()) {
                val success = databaseHelper.updateWeight(
                    idText.toInt(),
                    date,
                    weightText.toDouble()
                )

                if (success) {
                    Toast.makeText(this, "Weight updated", Toast.LENGTH_SHORT).show()
                    weightList.text = databaseHelper.getAllWeights()
                } else {
                    Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter ID, date, and weight", Toast.LENGTH_SHORT).show()
            }
        }

        deleteButton.setOnClickListener {
            val idText = entryId.text.toString()

            if (idText.isNotEmpty()) {
                val success = databaseHelper.deleteWeight(idText.toInt())

                if (success) {
                    Toast.makeText(this, "Weight deleted", Toast.LENGTH_SHORT).show()
                    weightList.text = databaseHelper.getAllWeights()
                } else {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter an ID to delete", Toast.LENGTH_SHORT).show()
            }
        }

        smsSettingsButton.setOnClickListener {
            val intent = Intent(this, SmsPermissionActivity::class.java)

            intent.putExtra("currentWeight", weightInput.text.toString())
            intent.putExtra("goalWeight", goalWeightInput.text.toString())

            startActivity(intent)
        }
    }

    private fun sendGoalSms() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                val smsManager = SmsManager.getDefault()

                smsManager.sendTextMessage(
                    "5551234567",
                    null,
                    "Congratulations! You reached your goal weight!",
                    null,
                    null
                )

                Toast.makeText(this, "Goal reached SMS sent", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Goal reached, but SMS could not be sent", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Goal reached, but SMS permission was denied", Toast.LENGTH_SHORT).show()
        }
    }
}