package com.example.weighttracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class WeightDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "WeightTracker.db"
        private const val DATABASE_VERSION = 1

        // User Table
        const val TABLE_USERS = "users"
        const val COLUMN_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"

        // Weight Table
        const val TABLE_WEIGHTS = "weights"
        const val COLUMN_DATE = "date"
        const val COLUMN_WEIGHT = "weight"
    }

    override fun onCreate(db: SQLiteDatabase) {

        val createUsersTable = """
        CREATE TABLE $TABLE_USERS (
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_USERNAME TEXT UNIQUE,
            $COLUMN_PASSWORD TEXT
        )
    """

        val createWeightsTable = """
        CREATE TABLE $TABLE_WEIGHTS (
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_DATE TEXT,
            $COLUMN_WEIGHT REAL
        )
    """

        db.execSQL(createUsersTable)
        db.execSQL(createWeightsTable)
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHTS")
        onCreate(db)
    }

    // CREATE USER
    fun addUser(username: String, password: String): Boolean {

        val db = writableDatabase

        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }

        val result = db.insert(TABLE_USERS, null, values)

        return result != -1L
    }

    // LOGIN CHECK
    fun checkUser(username: String, password: String): Boolean {

        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME=? AND $COLUMN_PASSWORD=?",
            arrayOf(username, password)
        )

        val exists = cursor.count > 0

        cursor.close()

        return exists
    }

    // CREATE WEIGHT ENTRY
    fun addWeight(date: String, weight: Double): Boolean {

        val db = writableDatabase

        val values = ContentValues().apply {
            put(COLUMN_DATE, date)
            put(COLUMN_WEIGHT, weight)
        }

        val result = db.insert(TABLE_WEIGHTS, null, values)

        return result != -1L
    }

    // READ ALL WEIGHTS
    fun getAllWeights(): String {

        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_WEIGHTS ORDER BY $COLUMN_ID DESC",
            null
        )

        val result = StringBuilder()

        while (cursor.moveToNext()) {

            val id =
                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))

            val date =
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE))

            val weight =
                cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT))

            result.append(
                "ID: $id | $date | $weight lbs\n"
            )
        }

        cursor.close()

        return if (result.isEmpty()) {
            "No weight entries found."
        } else {
            result.toString()
        }
    }

    // UPDATE WEIGHT ENTRY
    fun updateWeight(
        id: Int,
        date: String,
        weight: Double
    ): Boolean {

        val db = writableDatabase

        val values = ContentValues().apply {
            put(COLUMN_DATE, date)
            put(COLUMN_WEIGHT, weight)
        }

        val result = db.update(
            TABLE_WEIGHTS,
            values,
            "$COLUMN_ID=?",
            arrayOf(id.toString())
        )

        return result > 0
    }

    // DELETE WEIGHT ENTRY
    fun deleteWeight(id: Int): Boolean {

        val db = writableDatabase

        val result = db.delete(
            TABLE_WEIGHTS,
            "$COLUMN_ID=?",
            arrayOf(id.toString())
        )

        return result > 0
    }

}
