package com.example.weighttracker

import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.ceil

object WeightAnalyzer {


    // Calculates an average for a calendar-day window.
    fun calculateMovingAverage(
        entries: List<WeightEntry>,
        days: Long
    ): Double? {

        if (entries.isEmpty() || days <= 0) {
            return null
        }

        val latestDate = entries.last().date
        val startDate = latestDate.minusDays(days - 1)

        var runningTotal = 0.0
        var count = 0

        for (entry in entries) {
            if (
                !entry.date.isBefore(startDate) &&
                !entry.date.isAfter(latestDate)
            ) {
                runningTotal += entry.weight
                count++
            }
        }

        if (count == 0) {
            return null
        }

        return runningTotal / count
    }

    // Calculates the average weekly rate of weight change.
    fun calculateWeeklyChange(entries: List<WeightEntry>): Double? {

        if (entries.size < 2) {
            return null
        }

        val firstEntry = entries.first()
        val lastEntry = entries.last()

        val daysBetween =
            java.time.temporal.ChronoUnit.DAYS.between(
                firstEntry.date,
                lastEntry.date
            )

        if (daysBetween <= 0) {
            return null
        }

        val totalChange =
            lastEntry.weight - firstEntry.weight

        return (totalChange / daysBetween) * 7.0
    }

    // Classifies the recent weight trend.
    fun determineTrend(entries: List<WeightEntry>): String {

        if (entries.size < 2) {
            return "Not enough data"
        }

        val recentCount = minOf(7, entries.size)

        val recentEntries =
            entries.takeLast(recentCount)

        val previousEntries =
            entries.dropLast(recentCount).takeLast(recentCount)

        if (previousEntries.isEmpty()) {
            val change =
                recentEntries.last().weight -
                        recentEntries.first().weight

            return when {
                change < -0.5 -> "Decreasing"
                change > 0.5 -> "Increasing"
                else -> "Stable"
            }
        }

        val recentAverage =
            recentEntries.map { it.weight }.average()

        val previousAverage =
            previousEntries.map { it.weight }.average()

        val difference =
            recentAverage - previousAverage

        return when {
            difference < -0.5 -> "Decreasing"
            difference > 0.5 -> "Increasing"
            else -> "Stable"
        }
    }

    // Detects whether recent weight measurements indicate a plateau.
    fun detectPlateau(entries: List<WeightEntry>): Boolean {

        if (entries.size < 7) {
            return false
        }

        val recentEntries =
            entries.takeLast(7)

        val weights =
            recentEntries.map { it.weight }

        val highestWeight =
            weights.maxOrNull() ?: return false

        val lowestWeight =
            weights.minOrNull() ?: return false

        val range =
            highestWeight - lowestWeight

        return range <= 1.0
    }

    // Estimates when the user may reach the goal weight.
    fun estimateGoalDate(
        entries: List<WeightEntry>,
        goalWeight: Double
    ): LocalDate? {

        if (entries.size < 2) {
            return null
        }

        val currentWeight =
            entries.last().weight

        if (abs(currentWeight - goalWeight) < 0.1) {
            return entries.last().date
        }

        val weeklyChange =
            calculateWeeklyChange(entries) ?: return null

        if (abs(weeklyChange) < 0.01) {
            return null
        }

        val remainingWeight =
            goalWeight - currentWeight

        // The rate must be moving toward the goal.
        if (
            (remainingWeight < 0 && weeklyChange >= 0) ||
            (remainingWeight > 0 && weeklyChange <= 0)
        ) {
            return null
        }

        val weeksRemaining =
            abs(remainingWeight / weeklyChange)

        val daysRemaining =
            ceil(weeksRemaining * 7.0).toLong()

        return entries.last().date.plusDays(daysRemaining)
    }
}