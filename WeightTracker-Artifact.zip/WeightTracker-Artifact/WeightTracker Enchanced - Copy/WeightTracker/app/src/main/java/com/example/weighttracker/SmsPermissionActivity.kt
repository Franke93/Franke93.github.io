package com.example.weighttracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SmsPermissionActivity : ComponentActivity() {

    private val SMS_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_permission)

        val enableButton =
            findViewById<Button>(R.id.buttonEnableSms)

        val skipButton =
            findViewById<Button>(R.id.buttonSkipSms)

        val statusText =
            findViewById<TextView>(R.id.textSmsStatus)

        enableButton.setOnClickListener {

            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.SEND_SMS),
                    SMS_PERMISSION_CODE
                )

            } else {

                statusText.text =
                    "Goal weight notifications are enabled."
            }
        }

        skipButton.setOnClickListener {

            statusText.text =
                "Goal weight notifications are disabled."
        }
    }
}