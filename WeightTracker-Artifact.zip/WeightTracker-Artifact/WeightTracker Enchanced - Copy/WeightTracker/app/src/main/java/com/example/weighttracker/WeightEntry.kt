package com.example.weighttracker

import java.time.LocalDate

data class WeightEntry(
    val id: Int,
    val date: LocalDate,
    val weight: Double
)