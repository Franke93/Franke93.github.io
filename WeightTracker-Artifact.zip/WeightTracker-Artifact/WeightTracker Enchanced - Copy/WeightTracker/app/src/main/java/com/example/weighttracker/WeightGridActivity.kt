package com.example.weighttracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import android.text.Editable
import android.text.TextWatcher
import java.util.Locale


class WeightGridActivity : ComponentActivity() {

    private lateinit var databaseHelper: WeightDatabaseHelper
    private lateinit var weightList: TextView
    private lateinit var progressAnalysis: TextView
    private lateinit var goalWeightInput: EditText

    companion object {
        private const val SMS_PERMISSION_CODE = 100
    }

    private val dateFormatter =
        DateTimeFormatter.ofPattern("MM/dd/yyyy")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_grid)

        databaseHelper = WeightDatabaseHelper(this)

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_CODE
            )
        }

        weightList =
            findViewById(R.id.textWeightList)

        progressAnalysis =
            findViewById(R.id.textProgressAnalysis)

        val entryId =
            findViewById<EditText>(R.id.editTextEntryId)

        val dateInput =
            findViewById<EditText>(R.id.editTextDate)

        val weightInput =
            findViewById<EditText>(R.id.editTextWeight)

        goalWeightInput =
            findViewById(R.id.editTextGoalWeight)

        val addButton =
            findViewById<Button>(R.id.buttonAddWeight)

        val updateButton =
            findViewById<Button>(R.id.buttonUpdateWeight)

        val deleteButton =
            findViewById<Button>(R.id.buttonDeleteWeight)

        val smsSettingsButton =
            findViewById<Button>(R.id.buttonSmsSettings)

        refreshData()

        goalWeightInput.addTextChangedListener(object : TextWatcher {

            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
                updateProgressAnalysis()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        // ADD WEIGHT
        addButton.setOnClickListener {

            val date =
                dateInput.text.toString().trim()

            val weightText =
                weightInput.text.toString().trim()

            if (date.isEmpty() || weightText.isEmpty()) {
                Toast.makeText(
                    this,
                    "Enter date and weight",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            if (!isValidDate(date)) {
                Toast.makeText(
                    this,
                    "Enter date as MM/DD/YYYY",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val currentWeight =
                weightText.toDoubleOrNull()

            if (currentWeight == null || currentWeight <= 0) {
                Toast.makeText(
                    this,
                    "Enter a valid weight",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val success =
                databaseHelper.addWeight(
                    date,
                    currentWeight
                )

            if (success) {
                Toast.makeText(
                    this,
                    "Weight added",
                    Toast.LENGTH_SHORT
                ).show()

                refreshData()

                val goalWeight =
                    goalWeightInput.text
                        .toString()
                        .toDoubleOrNull()

                if (
                    goalWeight != null &&
                    currentWeight <= goalWeight
                ) {
                    sendGoalSms()
                }
            } else {
                Toast.makeText(
                    this,
                    "Failed to add weight",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // UPDATE WEIGHT
        updateButton.setOnClickListener {

            val idText =
                entryId.text.toString().trim()

            val date =
                dateInput.text.toString().trim()

            val weightText =
                weightInput.text.toString().trim()

            if (
                idText.isEmpty() ||
                date.isEmpty() ||
                weightText.isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Enter ID, date, and weight",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val id =
                idText.toIntOrNull()

            if (id == null || id <= 0) {
                Toast.makeText(
                    this,
                    "Enter a valid entry ID",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            if (!isValidDate(date)) {
                Toast.makeText(
                    this,
                    "Enter date as MM/DD/YYYY",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val weight =
                weightText.toDoubleOrNull()

            if (weight == null || weight <= 0) {
                Toast.makeText(
                    this,
                    "Enter a valid weight",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val success =
                databaseHelper.updateWeight(
                    id,
                    date,
                    weight
                )

            if (success) {
                Toast.makeText(
                    this,
                    "Weight updated",
                    Toast.LENGTH_SHORT
                ).show()

                refreshData()
            } else {
                Toast.makeText(
                    this,
                    "Update failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // DELETE WEIGHT
        deleteButton.setOnClickListener {

            val idText =
                entryId.text.toString().trim()

            if (idText.isEmpty()) {
                Toast.makeText(
                    this,
                    "Enter an ID to delete",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val id =
                idText.toIntOrNull()

            if (id == null || id <= 0) {
                Toast.makeText(
                    this,
                    "Enter a valid entry ID",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val success =
                databaseHelper.deleteWeight(id)

            if (success) {
                Toast.makeText(
                    this,
                    "Weight deleted",
                    Toast.LENGTH_SHORT
                ).show()

                refreshData()
            } else {
                Toast.makeText(
                    this,
                    "Delete failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // SMS SETTINGS
        smsSettingsButton.setOnClickListener {

            val intent =
                Intent(
                    this,
                    SmsPermissionActivity::class.java
                )

            intent.putExtra(
                "currentWeight",
                weightInput.text.toString()
            )

            intent.putExtra(
                "goalWeight",
                goalWeightInput.text.toString()
            )

            startActivity(intent)
        }
    }

    // Refreshes both weight history and progress analysis.
    private fun refreshData() {

        weightList.text =
            databaseHelper.getAllWeights()

        updateProgressAnalysis()
    }

    // Runs the algorithms and displays the results.
    private fun updateProgressAnalysis() {

        val history =
            databaseHelper.getWeightHistory()

        if (history.isEmpty()) {
            progressAnalysis.text =
                "Add weight entries to view progress analysis."

            return
        }

        val sevenDayAverage =
            WeightAnalyzer.calculateMovingAverage(
                history,
                7L
            )

        val thirtyDayAverage =
            WeightAnalyzer.calculateMovingAverage(
                history,
                30L
            )

        val weeklyChange =
            WeightAnalyzer.calculateWeeklyChange(
                history
            )

        val trend =
            WeightAnalyzer.determineTrend(
                history
            )

        val plateau =
            WeightAnalyzer.detectPlateau(
                history
            )

        val goalWeight =
            goalWeightInput.text
                .toString()
                .toDoubleOrNull()

        val estimatedGoalDate =
            if (goalWeight != null && goalWeight > 0) {
                WeightAnalyzer.estimateGoalDate(
                    history,
                    goalWeight
                )
            } else {
                null
            }

        val sevenDayText =
            if (sevenDayAverage != null) {
                String.format(Locale.US,
                    "%.1f lbs",
                    sevenDayAverage
                )
            } else {
                "Not enough data"
            }

        val thirtyDayText =
            if (thirtyDayAverage != null) {
                String.format(Locale.US,
                    "%.1f lbs",
                    thirtyDayAverage
                )
            } else {
                "Not enough data"
            }

        val weeklyChangeText =
            if (weeklyChange != null) {
                String.format(Locale.US,
                    "%+.2f lbs/week",
                    weeklyChange
                )
            } else {
                "Not enough data"
            }

        val plateauText =
            if (history.size < 7) {
                "Not enough data"
            } else if (plateau) {
                "Possible plateau detected"
            } else {
                "No plateau detected"
            }

        val goalDateText =
            when {
                goalWeight == null || goalWeight <= 0 ->
                    "Enter a goal weight"

                estimatedGoalDate != null ->
                    estimatedGoalDate.format(dateFormatter)

                else ->
                    "Cannot estimate from current trend"
            }

        progressAnalysis.text =
            """
            7-Day Average: $sevenDayText
            30-Day Average: $thirtyDayText
            Average Weekly Change: $weeklyChangeText
            Trend: $trend
            Plateau: $plateauText
            Estimated Goal Date: $goalDateText
            """.trimIndent()
    }

    // Confirms that dates use MM/DD/YYYY.
    private fun isValidDate(date: String): Boolean {

        return try {
            LocalDate.parse(
                date,
                dateFormatter
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    private fun sendGoalSms() {

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                val smsManager =
                    SmsManager.getDefault()

                smsManager.sendTextMessage(
                    "5551234567",
                    null,
                    "Congratulations! You reached your goal weight!",
                    null,
                    null
                )

                Toast.makeText(
                    this,
                    "Goal reached SMS sent",
                    Toast.LENGTH_SHORT
                ).show()

            } catch (_: Exception) {

                Toast.makeText(
                    this,
                    "Goal reached, but SMS could not be sent",
                    Toast.LENGTH_SHORT
                ).show()
            }

        } else {

            Toast.makeText(
                this,
                "Goal reached, but SMS permission was denied",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}